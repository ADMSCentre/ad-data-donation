from dataclasses import dataclass


class CommandUIRender:
    __slots__ = "page"

    def __init__(self, page):
        self.page = page

    def toDict(self):
        dict = {}
        dict["__type__"] = "CommandUIRender"
        dict["page"] = self.page.toDict()
        return dict

class CommandSystemRestart:
    __slots__ = "target"
    
    def __init__(self, target):
        self.target = target
    
    def toDict(self):
        dict = {}
        dict["__type__"] = "CommandSystemRestart"
        dict["target"] = self.target
        return dict

class CommandSystemDonate:
    __slots__ = "key", "json_string"

    def __init__(self, key, json_string):
        self.key = key
        self.json_string = json_string

    def toDict(self):
        dict = {}
        dict["__type__"] = "CommandSystemDonate"
        dict["key"] = self.key
        dict["json_string"] = self.json_string
        return dict

@dataclass
class CommandSystemDonateFilesProps:
    platform: str

class CommandSystemDonateFiles:
    __slots__ = "key", "file_contents", "props"

    def __init__(self, key, fileContents, props: CommandSystemDonateFilesProps):
        self.key = key
        self.file_contents = fileContents
        self.props = props

    def toDict(self):
        dict = {}
        dict["__type__"] = "CommandSystemDonateFiles"
        dict["key"] = self.key
        dict["fileContents"] = self.file_contents
        dict["props"] = self.props.__dict__ if self.props else None
        return dict

class CommandSystemExit:
    __slots__ = "code", "info"

    def __init__(self, code, info):
        self.code = code
        self.info = info

    def toDict(self):
        dict = {}
        dict["__type__"] = "CommandSystemExit"
        dict["code"] = self.code
        dict["info"] = self.info
        return dict
